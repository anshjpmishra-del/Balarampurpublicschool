package com.balarampur.school;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.Gravity;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.net.Uri;

public class MainActivity extends Activity {
    private static final String HOME_URL =
        "https://balarampur-public-school-portal-43l5yj.v2.appdeploy.ai/";

    private WebView webView;
    private ProgressBar progress;
    private TextView offlineMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.WHITE);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        layout.addView(progress, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 5));

        offlineMessage = new TextView(this);
        offlineMessage.setText("Internet connection is required. Connect to the internet and tap Reload.");
        offlineMessage.setTextColor(Color.DKGRAY);
        offlineMessage.setTextSize(16);
        offlineMessage.setGravity(Gravity.CENTER);
        offlineMessage.setPadding(28, 28, 28, 12);
        offlineMessage.setVisibility(View.GONE);
        layout.addView(offlineMessage);

        TextView reload = new TextView(this);
        reload.setText("RELOAD");
        reload.setTextColor(Color.rgb(150, 0, 0));
        reload.setTextSize(15);
        reload.setGravity(Gravity.CENTER);
        reload.setPadding(20, 12, 20, 20);
        reload.setVisibility(View.GONE);
        reload.setOnClickListener(v -> {
            offlineMessage.setVisibility(View.GONE);
            reload.setVisibility(View.GONE);
            webView.reload();
        });
        layout.addView(reload);

        webView = new WebView(this);
        layout.addView(webView, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, false);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                String host = uri.getHost();
                if ("https".equalsIgnoreCase(scheme) &&
                    host != null && (host.equals("balarampur-public-school-portal-43l5yj.v2.appdeploy.ai")
                    || host.endsWith(".appdeploy.ai"))) {
                    return false;
                }
                if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) {
                    try {
                        startActivity(new android.content.Intent(
                            android.content.Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored) {}
                    return true;
                }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) {
                    offlineMessage.setVisibility(View.VISIBLE);
                    reload.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                offlineMessage.setVisibility(View.GONE);
                reload.setVisibility(View.GONE);
                CookieManager.getInstance().flush();
            }
        });

        setContentView(layout);
        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(HOME_URL);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
