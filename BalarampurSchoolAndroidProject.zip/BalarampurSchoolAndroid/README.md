# Balarampur Public School Android wrapper

This is an Android WebView wrapper for the existing AppDeploy-hosted school website.

- App label: Balarampur Public School
- Package: `com.balarampur.school`
- Minimum Android: 6.0 (API 23); designed for Android 11+
- Requires internet for live website/database access
- Uses the existing website login and server-side database; it does not create a second database.

## Build an APK with GitHub Actions

1. Create a GitHub repository and upload all files in this folder.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and press **Run workflow** (or push to `main`).
4. When it finishes, open the workflow run and download the artifact named `Balarampur-School-debug-apk`.
5. Extract the artifact to get `app-debug.apk`, then install it on your Android device. You may need to allow installation from that file manager/browser.

## Important

- This project is a WebView app, not a fully native rewrite of the school portal.
- Student data continues to be served by the existing AppDeploy website/database.
- No AppDeploy secret keys or database credentials are embedded in the APK.
- A signed release APK for distribution to a school should be created with a private signing key. Do not share that key or its passwords.
- If the website URL changes, update `HOME_URL` in `MainActivity.java` and rebuild.
